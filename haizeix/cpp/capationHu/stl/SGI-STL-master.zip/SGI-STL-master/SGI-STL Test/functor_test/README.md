## 仿函数(functor)-Code Test

* [函数对象 function object](https://github.com/steveLauwh/SGI-STL/tree/master/SGI-STL%20Test/functor_test/functionObject.cpp)
